<?php
include "nav.php";
include"baza.php";
$veza = spojiSeNaBazu();
$upit = "SELECT naziv , izborno_mjesto_id FROM izborno_mjesto";
$rezultat = izvrsiUpit($veza,$upit);
$lista = array();
$grad="";
$rezultat1 = "";
$rezultat2 = "";
$ispis_pobjednika="";


if (isset($_POST['submit'])||isset($_POST['submit_izbor']) )
{
	while($red = mysqli_fetch_array($rezultat))
		{
			if ($_POST['grad']== $red ['izborno_mjesto_id'])
				$grad = $grad . "<option value = ".$red["izborno_mjesto_id"]. " selected >".$red['naziv']."</option>";
			else 
				$grad = $grad . "<option value = ".$red["izborno_mjesto_id"]. ">".$red['naziv']."</option>";
		}	
}

while($red = mysqli_fetch_array($rezultat))
		{
			$grad = $grad . "<option value = ".$red["izborno_mjesto_id"]. ">".$red['naziv']."</option>";
		
		}	
	
	
	
		
		
		
		
		
	

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Početna</title>
	<meta name="početna" content="prošli izbori" />
	<link href="stil_nav.css"  rel="stylesheet" type="text/css" />
	<link href="stil_inputa.css"  rel="stylesheet" type="text/css" />
	<style>
	form
	{
	position:absolute;
	top:60%;
	left:19.99%;
	width:59.8%;
	border:2px solid #ccc; 
    border-radius: 5px;
	background:white;
	font-size:20px;
	}
	h1 
	{
	position:absolute;
	top:45%;
	left:41.5%;
	font-family:arial;
	font-weight:normal;
	width:19%;
	text-align:center;
	}
	select
	{
	padding:5px; 
    border:2px solid #ccc; 
    border-radius: 5px;
	margin-left:30%;
	text-align:center;
	color:chocolate;
	background:#fbfbf0;
	}
	select:focus
	{
	border:3px solid #fbfb4a;
	border-radius: 5px;
	}
	option
	{
	color:chocolate;
	font-family:serif;
	font-size:20px;
	border:3px solid #fbfb4a;
	border-radius: 5px;
	}
	#submit_izbor:hover{background:#fbfb4a}
	#submit{margin-right:32.8%;}
	input[type=radio]{
		margin-top:10%;
		margin-bottom:4%;
		border-bottom:1px solid;
	}
	#submit_izbor{margin:2%; position:fixed;
    top:90%;
    left:60%;}
	#oznaceno{
	color:#882000;
	font-weight:bold;
	font-size:30px;
	}
	p
	{
		margin-left:auto;
		margin-right:auto;
		font-size:30px;
		color:#882000;
		margin-top:7%;
		margin-bottom:0%;
		margin-left:43%;
		font-family:arial;
		
	}
	
	</style>

</head>

<body>
<header>
        <nav>
            <ul>

                <li>
                    <a href="o_autoru.html">O autoru</a>
                </li>
                <li>
                    <a href="prijava.php">Prijava</a>
                </li>
		 <li>
                    <a href="index.php " id="indexstr">Index</a>
                </li>
				<?php echo $moderator;?>
                
				<?php echo $kor_nav;?>
				
				<?php echo $admin;?>
				

            </ul>
        </nav>
		
</header>



<h1>PROŠLI IZBORI</h1>
<form action="<?php echo $_SERVER["PHP_SELF"]?>" name="grad" method="POST" id="prijava">
<label  style="margin-left:30%;" for="grad">Odaberite mjesto izbora:</label><br>
<select name="grad" style="font-family:serif; font-size:20px; width:300px;">
  <?php echo $grad;?>
</select><br>
<input name="submit" style="margin-bottom:0.5%;" id="submit" type="submit" value="Odaberi" />
<?php 
$izbor="";
if(isset($_POST["submit"]) || isset($_POST["submit_izbor"]))
	{
		$id_grada= $_POST["grad"];
		$upit="SELECT * FROM izbor WHERE izbor_id AND izborno_mjesto_id='$id_grada' AND datum_vrijeme_zavrsetka < now() ORDER BY datum_vrijeme_zavrsetka DESC";
		$rezultat1=izvrsiUpit($veza,$upit);
		while($red = mysqli_fetch_array($rezultat1))
			{
			if (isset($_POST["izbor"]) && $_POST["izbor"] == $red['izbor_id'])
                        {
                             
                
				$izbor=$izbor. "<input name='izbor' type='radio' value= ".$red['izbor_id']." checked>"."<label id='oznaceno'>". $red["naziv"]." <br> ".$a=date("d.m.Y.",strtotime( $red['datum_vrijeme_zavrsetka'])) . "<br>".$red["opis"]." </label>"."<br>";
                        }
                                else
                                {
				$izbor=$izbor. "<input name='izbor' type='radio' value= ".$red['izbor_id'].">"."<label>"."<strong>Naziv izbora:</strong> " .$red["naziv"]."<br>   <strong>Vrijeme završetka:</strong>  ".$a=date("d.m.Y.",strtotime( $red['datum_vrijeme_zavrsetka']))."<br>"."   <strong>Opis:</strong>   " .$red["opis"]."</label>". "<br>";
                                }
			}
		print_r($izbor);
		echo '<input name="submit_izbor" id="submit_izbor" type="submit" value="Ispiši pobjednika" />';
		
	
	
	}
	$text="";
if(isset($_POST["submit_izbor"])) 
		{
		
		$id_pobjednika=$_POST ['izbor'];
		
		$upit="SELECT * FROM `korisnik` JOIN kandidat ON kandidat.korisnik_id=korisnik.korisnik_id JOIN glas ON glas.kandidat_id=kandidat.kandidat_id where izbor_id= '$id_pobjednika'  GROUP by glas.kandidat_id order by COUNT(*) DESC LIMIT 1";
		$rezultat2=izvrsiUpit($veza,$upit);
		$pobjednik=array();
		$pobjednik=mysqli_fetch_array($rezultat2);
		
		$ispis_pobjednika= "<br><br>"."Ime i Prezime: ".$pobjednik['ime']."   ".$pobjednik['prezime']."  <br><br> "."Email: ". $pobjednik['email']."<br><br>". "Slika: ". "<img height='220' width='220' src='".$pobjednik['slika']."'>"." <br><br>  "."Video: "."<video width='320' height='240' controls><source src='".$pobjednik['video']."' type='video/mp4'>"."<br><br>Životopis:<br><br>".$pobjednik['zivotopis'];
		$text="<p>Pobjednik</p>";
		}
		
zatvoriVezuNaBazu($veza);
?>
<div id="ispis_pobjednika" >
<?php echo $text; ?>
<?php
echo $ispis_pobjednika."<br><br><br>"

?>
</div>
</form>
</body>
</html>