<?php
include "baza.php";
include "nav.php";
$veza = SpojiSeNaBazu();
if ($tip==4)
	header ("Location: prijava.php");
if (empty($_COOKIE))
	header ("Location: index.php");
$id_korisnika = $_COOKIE ["id_korisnika"];


if (isset($_POST["kandidirajse"])) 
	{
        
        $id_izbora=$_POST ['izbor'];
	header("Location:kandidirajse.php?id_izbora=".$id_izbora);	
	}
session_start();

if (isset($_GET['id_izbora']))
{
    $id_izbora=$_GET['id_izbora'];
    $_SESSION["id_izbora"] = $id_izbora;
}
$id_izbora=$_SESSION['id_izbora'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <link href="stil_nav.css"  rel="stylesheet" type="text/css" />
	<link href="stil_inputa.css"  rel="stylesheet" type="text/css" />
    <title>Korisni</title>
	
        <style>
            
           table{
                border: 1px solid #CCCCCC;
                border-radius: 6px 6px 6px 6px;
                border-radius: 6px 6px 6px 6px;
                border-radius: 6px 6px 6px 6px;
                box-shadow: 0 1px 1px #CCCCCC;
                border-spacing: 0;
                font-size:20px;
                margin-top: 20%;
                z-index:10;
                margin-left:auto;
                margin-right:auto;
            }
            .caption{
                font-size:30px;
            }
            div{
                margin-left:auto;
                margin-right:auto;
                text-align:center;
            }
            form{
                margin-top:10%;
                margin-left:auto;
                margin-right:auto;
                width:60%;
                background-color:white;
            }
            #input{
                font-size:20px;
            }
            #botun{
                width:15%;
                margin-left:auto;
                margin-right:auto;
                margin-bottom:3%;
            }
            input[type=submit]:hover{background:#fbfb4a}
            #kandidirajse{background-color: inherit;}
           
        </style>
</head>
<body>
<header>
        <nav>
            <ul>

                <li>
                    <a href="o_autoru.html">O autoru</a>
                </li>
             
                <li>
                    <a href="korisnik_r.php">Korisnik</a>
                </li>
				<li>
                    <a href="index.php">Index</a>
                </li>
				
                    <?php echo $moderator;?>
                
				
				
					<?php echo $admin;?>
				

            </ul>
        </nav>
</header>
    
    <table border='1px'>
    <caption>ODABRANI IZBOR</caption>
<?php

$upit= "select * FROM izbor where izbor_id='$id_izbora'";
$rezultat=izvrsiUpit($veza,$upit);
print "
 <tr>
        <th>Naziv izbora</th>
        <th>Datum završetka</th> 
        <th>Opis</th>
        </tr>";


while ($red = mysqli_fetch_array($rezultat)) {
    $a = date("d.m.Y.", strtotime($red['datum_vrijeme_zavrsetka']));
    print "<tr><td>". $red['naziv'] . "</td><td>" . $a . "</td><td>" . $red['opis'] . "</td>";
}?>
    </table>
    <div id="botun">
        <form id="kandidirajse" action="glasanje.php" method="POST">
            
            <input name="izbor" type="hidden" value="<?php echo $id_izbora; ?>"/>
            <br>
            <input style="float:right; margin:2%;" name="kandidirajse" id="submi_kandidata" type="submit" value="Kandidiraj se" />
            <br>
        </form>
    </div>
    <form  action='glasanje.php' method='POST'>
    <div class="caption">POPIS KANDIDATA NA IZBORIMA</div>
    <input type="hidden" name="id_izbora" value="<?php echo $id_izbora;?>"/>
<?php
$upit1="select * from kandidat join korisnik on kandidat.korisnik_id=korisnik.korisnik_id WHERE izbor_id='$id_izbora'";
		$rezultat3=izvrsiUpit($veza,$upit1);
		$kandidat="";
		
		
		
		while($red = mysqli_fetch_array($rezultat3))
		{
			
			if ($red['status']== "K"){
			$kandidat="<br>".$kandidat. "<input name='izbor' type='radio' value=".$red['kandidat_id']." ><div id='input'>". "<strong>Ime:  </strong>".$red["ime"]."   <strong>Prezime:   </strong>".$red["prezime"] . "    <strong>Email:    </strong>".$red["email"]." <br>   <strong>Video:</strong><video width='320' height='240' controls> <source src='".$red['video']."' type='video/mp4'> </video></div><br>";	
                        }	
		}



                

            
                $kand_lista=array();
                $glasani_kand=array();
                $a="SELECT * FROM `kandidat`WHERE izbor_id='$id_izbora'";
                $b=izvrsiUpit($veza,$a);
                while ($red1=mysqli_fetch_array($b)){
                    
                    $kand_lista[]=$red1["kandidat_id"];
                }
                
                $c="select * from glas where korisnik_id='$id_korisnika'";
                $k=izvrsiUpit($veza,$c);
                while ($red2=mysqli_fetch_array($k)){
                    
                    $glasani_kand[]=$red2['kandidat_id'];
                }
                
                $usporedba=array_diff($kand_lista, $glasani_kand);    
               
?>

    
<div>
    
   
 <?php   
		echo $kandidat;
		
                
                if ($usporedba==$kand_lista)
                {
                    $P="greska";
                    echo '<input style="float:right; margin:2%;" name="submit_kandidata" id="submi_kandidata" type="submit" value="Odaberi" />';
                   
                }
		
		if (!isset($P))
                {
                     echo "<div style='color:red; font-size:35px'><strong>Već ste glasali na odabranom izboru</strong></div>";
                }
?>
</form>
<?php 
if (isset($_POST["submit_kandidata"])){
    $kandidat_id=$_POST['izbor'];
    $upit3="INSERT INTO glas VALUES('$id_korisnika','$kandidat_id')";
    $rezultat4=izvrsiUpit($veza,$upit3);
    echo "<div style='color:green'><strong>Glasanje uspješno</strong></div>";
    header("Location: glasanje.php");
}

?>
</div>
</body>
</html>