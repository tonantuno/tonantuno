<?php
include "nav.php";
include "baza.php";
if ($tip == 4)
    header("Location: prijava.php");
if (empty($_COOKIE))
    header("Location: index.php");
if ($_COOKIE["tip"] == 3)
    header("Location: prijava.php");
$veza = SpojiSeNaBazu();
$moderator_id = $_COOKIE["id_korisnika"];
$grad = "";



$upit = " SELECT * FROM izbor JOIN izborno_mjesto ON izborno_mjesto.izborno_mjesto_id=izbor.izborno_mjesto_id WHERE moderator_id = '$moderator_id' ";
$rez = izvrsiUpit($veza, $upit);

$upit_grad = "select * from izborno_mjesto where moderator_id = '$moderator_id'";
$gradovi = izvrsiUpit($veza, $upit_grad);


while ($red = mysqli_fetch_array($gradovi)) {
    $grad = $grad . "<option value = " . $red["izborno_mjesto_id"] . ">" . $red['naziv'] . "</option>";
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" />
        <title>Moderator</title>
        <link href="stil_nav.css"  rel="stylesheet" type="text/css" />
        <link href="stil_inputa.css"  rel="stylesheet" type="text/css" />
        <style>
            form{
                width:50%;
                margin-right:auto;
                margin-left:auto;
                margin-top:10%;
            }
            table{
                width:110%;
            }
            h1 
            {
                width:100%;
                text-align:center;
                margin-top:2%;
            }
            select{font-size:20px;}
            #submit
            {
                margin-bottom:2%;
                margin-right:2%;
                margin-top:1%;
            }
            #opis{
                width:95%;
                height:20px;
            }
            #grad
            {
                text-decoration:none;
                font-weight:bold;
                color:#ff8300;
            }
            #grad:hover
            {
                color:#6400ff
            }
            #izbor{margin-top:1%;}
            p {
                width:100%;
                text-align:center;
                color:red;
                font-size:16px;
            }
        </style>
    </head>

    <body>
        <header>
            <nav>
                <ul>

                    <li>
                        <a href="o_autoru.html">O autoru</a>
                    </li>

                    <li>
                        <a href="korisnik_r.php">Korisnik</a>
                    </li>
                    <li>
                        <a href="index.php">Index</a>
                    </li>

<?php echo $moderator; ?>



<?php echo $admin; ?>


                </ul>
            </nav>
        </header>
<form action="<?php echo $_SERVER["PHP_SELF"] ?>" name="unos_izbor" method="POST">
            <h1 id="izbor">Unesi izbor<h1>
                    <label for ="grad">Odaberite mjesto</label><br>
                    <select name="grad">
<?php echo $grad; ?>
                    </select><br>


                    <label for="naziv">Naziv</label><br>
                    <input name="naziv" type="text" required ><br>

                    <label for="video">Datum Početka</label><br>
                    <input name="datum_pocetka" type="text" placeholder ="dd.mm.gggg." required><br>

                    <label for="video">Vrijeme Početka</label><br>
                    <input name="vrijeme_pocetka" type="text" placeholder ="hh:mm:ss" required><br>


                    <label for="video">Opis</label><br>
                    <input name="opis" id="opis" type="text" required ><br>

                    <input name="submit" id="submit" type="submit" value="Unesi izbor" onclick="validateDate()">
<?php
if (isset($_POST['submit'])) {




    $naziv = $_POST['naziv'];

    $datum_v_p = $_POST['datum_pocetka'];
    $datum_p = date("Y-m-d", strtotime($datum_v_p));
    $datum_z = date("Y-m-d", strtotime("$datum_v_p + 7 day"));

    $noviformat_p = $datum_p;
    $noviformat_z = $datum_z;

    $vrijeme_pocetka = $_POST['vrijeme_pocetka'];

    $datum_pocetka = $noviformat_p . " " . $vrijeme_pocetka;
    $datum_zavrsetka = $noviformat_z . " " . $vrijeme_pocetka;


    $opis = $_POST['opis'];
    $izborno_mj_id = $_POST['grad'];


    $upit_izbor = "insert into izbor values (default, '$izborno_mj_id', '$naziv', '$datum_pocetka', '$datum_zavrsetka', '$opis') ";
    $unos = izvrsiUpit($veza, $upit_izbor);

    if ($unos != 1)
        echo "krivi format datuma ili vremena";
    else
        echo "<p> Uspješno unesen izbor<p>";
}
?>
</form>
        <br>

                    <table  border="1px" >
                        <tr>
                            <th colspan ="4"><h1 id="azuriranje">Ažuriraj izbor</h1></th>
                        </tr>
                        <tr>
                            <th>Naziv</th>
                            <th>Datum početka</th>
                            <th>Datum završetka</th>
                            <th>Opis</th>
                        </tr>
<?php
while ($red = mysqli_fetch_array($rez)) {
    ?>
                            <tr>
                                <td><a id="grad" href="azuriranje_izbor.php?izbor_id=<?php echo $red['izbor_id'] ?>"><?php echo $red['naziv']; ?></a></td>
                                <td><?php $a = date("d.m.Y.", strtotime($red['datum_vrijeme_pocetka']));
    echo $a;
    ?></td>
                                <td><?php $b = date("d.m.Y.", strtotime($red['datum_vrijeme_zavrsetka']));
    echo $b;
    ?></td>
                                <td><?php echo $red['5']; ?></td>
                            </tr>
    <?php
}
?>
</table>
</body>
</html>