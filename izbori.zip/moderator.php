<?php
include "nav.php";
include "baza.php";
$veza = SpojiSeNaBazu();
$moderator_id = $_COOKIE["id_korisnika"];

if ($tip == 4)
    header("Location: prijava.php");
if (empty($_COOKIE))
    header("Location: index.php");
if ($_COOKIE["tip"] == 3)
    header("Location: prijava.php");



$upit = " SELECT * FROM izbor JOIN izborno_mjesto ON izborno_mjesto.izborno_mjesto_id=izbor.izborno_mjesto_id WHERE moderator_id = '$moderator_id' ORDER BY datum_vrijeme_zavrsetka DESC ";
$rez = izvrsiUpit($veza, $upit);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" />
        <title>Moderator</title>
        <link href="stil_nav.css"  rel="stylesheet" type="text/css" />
        <link href="stil_inputa.css"  rel="stylesheet" type="text/css" />
        <style>
            table 
            {
                margin-top:5%;
                border: 1px solid #CCCCCC;
                border-radius: 6px 6px 6px 6px;
                border-radius: 6px 6px 6px 6px;
                border-radius: 6px 6px 6px 6px;
                box-shadow: 0 1px 1px #CCCCCC;
                border-spacing: 0;
                font-size:20px;
            }
            #rlista{
                margin-top: 5%;
                margin-left: 40%;
            }
           
            
            #statistika{
                margin-top:19%;
                width:100%;
                text-align:center;
            }
            h1{
                margin-top:5%;
                width:100%;
                text-align:center;
            }
            p {
                width:100%;
                text-align:center;
                color:red;
                font-size:16px;
            }
            form{
                margin-left:auto;
                margin-right:auto;
                width:30%;
            }
            input[type=submit]{
                margin-bottom:4%   
            }
            #rsubmit{
                float:left;
            }
            #kandidati{
                color:chocolate;
                font-size:20px
            }
            #izborgumb{
                background:#ccc;
                border:5px solid #ccc;
                border-radius:5px;
                margin-top:0%;
                margin-bottom:4%;
                color:white;
                text-decoration:none;
                font-family:arial;
                forn-size:20px;
                font-weight:bold;
                position:absolute;
                top:25%;
                left:43%;
                padding:10px;
            }
            #grad
            {
                text-decoration:none;
                font-weight:bold;
                color:#ff8300;
            }
            #grad:hover
            {
                color:#6400ff
            }
            #izborgumb:hover{background:#fbfb4a;border-color:#fbfb4a}
            #odjava
            {
                color: chocolate;
                text-decoration: none;
                border-radius: 30px;
                text-align: center;
                border:0px;
                transition:1s;
                font-size:20px;
            }

        </style>
    </head>
    <body>
        <header>
            <nav>
                <ul>

                    <li>
                        <a href="o_autoru.html">O autoru</a>
                    </li>

                    <li>
                        <a href="korisnik_r.php">Korisnik</a>
                    </li>
                    <li>
                        <a href="index.php">Index</a>
                    </li>

<?php echo $moderator; ?>



<?php echo $admin; ?>


                </ul>
            </nav>
        </header>
        <a id="odjava" style="margin-left:3%; top:25% ;position: absolute;" href="odjava.php">Odjavi se</a>
        <h1 id="statistika">Odaberite izbor za prikaz statistike istog</h1>
        <table align="center" border="1px" >
            <tr>
                <th colspan ="4" <h2>KREIRANI IZBORI</h2></th>
            </tr>
            <tr>
                <th>Naziv</th>
                <th>Datum početka</th>
                <th>Datum završetka</th>
                <th>Opis</th>
            </tr>
<?php
while ($red = mysqli_fetch_array($rez)) {
    ?>


                <tr>
                    <td><a id="grad" href="kandidati_glasovi.php?izbor_id=<?php echo $red['izbor_id'] ?>"><?php echo $red['naziv']; ?></a></td> 
                    <td><?php $a = date("d.m.Y.", strtotime($red['datum_vrijeme_pocetka']));
    echo $a;
    ?></td>
                    <td><?php $b = date("d.m.Y.", strtotime($red['datum_vrijeme_zavrsetka']));
    echo $b;
    ?></td>
                    <td><?php echo $red['opis']; ?></td>
                </tr>
                <?php
            }
            ?>

        </table>

        <?php
        $upit2 = " SELECT * FROM izbor JOIN izborno_mjesto ON izborno_mjesto.izborno_mjesto_id=izbor.izborno_mjesto_id WHERE moderator_id = '$moderator_id' AND datum_vrijeme_zavrsetka< NOW() ORDER BY datum_vrijeme_zavrsetka DESC ";
        $rez2 = izvrsiUpit($veza, $upit2);
        ?>
        <br>
        <a href="upravljanje_izborima.php" id="izborgumb">Unesi/Ažuriraj izbor</a>
        <h1 id="zavrseni">Završeni izbori</h1>
        <p>Kliknite na izbor za odabir pobjednika!</p>
        <table align="center" border="1px" >
            <tr>
                <th colspan ="4" <h2>ZAVRŠENI IZBORI</h2></th>
            </tr>
            <tr>
                <th>Naziv</th>
                <th>Datum početka</th>
                <th>Datum završetka</th>
                <th>Opis</th>
            </tr>
<?php
while ($red = mysqli_fetch_array($rez2)) {
    ?>

                <tr>
                    <td><a id="grad" href="pobjednik.php?izbor_id=<?php echo $red['izbor_id'] ?>"><?php echo $red['naziv']; ?></a></td> 
                    <td><?php $a = date("d.m.Y.", strtotime($red['datum_vrijeme_pocetka']));
            echo $a;
            ?></td>
                    <td><?php $b = date("d.m.Y.", strtotime($red['datum_vrijeme_zavrsetka']));
            echo $b;
            ?></td>
                    <td><?php echo $red['opis']; ?></td>
                </tr>



                <?php
            }
            ?>
        </table>
        <h1>Rang lista kandidatura</h1>
        <p>Upišite datume za koji period želite! <br>(obavezno stavite razmak između datuma i vremena!)<p>
        <form action="moderator.php" method="post" >
            <br>
            <label for="datumpocetka">Datum i vrijeme od</label>
            <br>
            <input type="text" name="datumpocetka" placeholder="dd.mm.gggg hh:mm:ss">
            <br>
            <label for="datumkraja">Datum i vrijeme do</label>
            <br>
            <input type="text" name="datumkraja" placeholder="dd.mm.gggg hh:mm:ss">
            <br>
            <input type="submit" id="rsubmit" name="submitdatum" value="Pošalji upit">
            <br>
            

        </form>
        <?php
        $broj = 0;
        if (isset($_POST['submitdatum'])) {



            $pocetak = $_POST['datumpocetka'];
            $kraj1 = $_POST['datumkraja'];


            $lista_p = explode(" ", $pocetak);
            $lista_k = explode(" ", $kraj1);

            $d_pocetak = strtotime($lista_p[0]);
            $d_kraj = strtotime($lista_k[0]);

            $noviformat_p = date('Y-m-d', $d_pocetak);
            $noviformat_k = date('Y-m-d', $d_kraj);

            $dv_pocetak = $noviformat_p . " " . $lista_p[1];
            $dv_kraj = $noviformat_k . " " . $lista_k[1];
            $upitranglista = "SELECT COUNT(*) AS rang_lista, k.ime, k.prezime FROM korisnik k, kandidat t, izbor i
WHERE k.korisnik_id = t.korisnik_id AND t.izbor_id=i.izbor_id AND t.status<>'O'
AND i.datum_vrijeme_zavrsetka BETWEEN '$dv_pocetak' AND '$dv_kraj'
AND i.izborno_mjesto_id IN (SELECT izborno_mjesto_id FROM izborno_mjesto WHERE moderator_id = '$moderator_id')
GROUP BY t.korisnik_id ORDER BY rang_lista DESC";

echo "<div id='rlista'>";
            $objektranglista = izvrsiUpit($veza, $upitranglista);
            while ($red = mysqli_fetch_array($objektranglista)) {
               
               $broj=$broj+1;
               
                echo $broj. " ) <strong>" . $red['ime'] . " " . $red['prezime'] ."</strong> broj kandidatura: ".$red['rang_lista']."<br>";
            }
        }
echo "</div>";
        ?>

    </body>
</html>

