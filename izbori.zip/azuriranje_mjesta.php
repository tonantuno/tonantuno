<?php
if (empty($_COOKIE))
	header ("Location: index.php");
if ($_COOKIE["tip"] != 1 )
	header ("Location: prijava.php");
include "nav.php";
include "baza.php";
$veza = SpojiSeNaBazu();
$mjesto_id =$_GET['mjesto_id'];

if (isset($_POST['submit']))
	{
	
	
	
	
	$moderator1 =$_POST['moderator'];
	$naziv=strtoupper($_POST['naziv']);
	$opis= $_POST['opis'];
	
	
	
	
	$upit_mjesto ="update izborno_mjesto set moderator_id='$moderator1', naziv='$naziv', opis='$opis' where izborno_mjesto_id='$mjesto_id'";
	izvrsiUpit($veza,$upit_mjesto);
	
	
	}




$upit_moderator= "select * from korisnik where tip_korisnika_id = '2'";
$moderator_objekt=izvrsiUpit($veza,$upit_moderator);
$moderator1="";
$oznaci="";

$upit_aktualni_moderator="select * from korisnik join izborno_mjesto on izborno_mjesto.moderator_id=korisnik.korisnik_id where izborno_mjesto_id='$mjesto_id'";
$moderator_aktualni_objekt=izvrsiUpit($veza,$upit_aktualni_moderator);
$moderator_aktualni_lista=mysqli_fetch_array($moderator_aktualni_objekt);
$id_aktualnog=$moderator_aktualni_lista['korisnik_id'];



while($red5 = mysqli_fetch_array($moderator_objekt))
		{
		
		if ($id_aktualnog === $red5['korisnik_id'])
		{
			$oznaci=" selected";
		}
		else $oznaci="";

			$moderator1 = $moderator1 . "<option value = ".$red5['korisnik_id'].$oznaci .">".$red5['ime']."   ".$red5['prezime']. "</option>";

		}


$upit_mjesto="select * from izborno_mjesto where izborno_mjesto_id='$mjesto_id'";
$rez_mjesto=izvrsiUpit($veza,$upit_mjesto);
$mjesto=mysqli_fetch_array($rez_mjesto);
?>

<!DOCTYPE html>
<html>
<meta charset="UTF-8" />
    <title>Moderator</title>
	<link href="stil_nav.css"  rel="stylesheet" type="text/css" />
	<link href="stil_inputa.css"  rel="stylesheet" type="text/css" />
	<style>
	form
	{
	margin-left:auto;
	margin-right:auto;
	width:30%;
	margin-top:5%;
	}
	h1{margin-top:15%;
	width:100%;
	text-align:center;
	}
	#submit{float:left;}
	textarea{
	border:2px solid #ccc; 
    border-radius: 5px;}
	</style>
<body>
<header>
        <nav>
            <ul>

                <li>
                    <a href="o_autoru.html">O autoru</a>
                </li>
             
                <li>
                    <a href="korisnik_r.php">Korisnik</a>
                </li>
				<li>
                    <a href="index.php">Index</a>
                </li>
				
                    <?php echo $moderator;?>
                
				
				
					<?php echo $admin;?>
				

            </ul>
        </nav>
    </header>
<h1>Ažuriranje izbornog mjesta</h1>
<form action="azuriranje_mjesta.php?mjesto_id=<?php echo $mjesto_id; ?>" name="unos_izbor" method="POST">
	<label for ="tip">Odaberite moderatora</label>
        <br>
	<select name="moderator">
		<?php echo $moderator1;?>
	</select>
        <br>

	
	<label for="naziv">Naziv</label>
        <br>
	<input name="naziv" type="text" value="<?php echo $mjesto['naziv']; ?>">
        <br>
	
	<label for="opis">Opis</label>
        <br>
	<textarea name="opis" rows="4" cols="50" type="text" ><?php echo $mjesto['opis']; ?></textarea>
        <br>

	<br>
        <input id="submit" name="submit" type="submit" value="Ažuriraj izborno mjesto">
<br>


</form>


</body>
</html>


