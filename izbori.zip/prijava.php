<?php
include "nav.php";
include "baza.php";
$veza = spojiSeNaBazu();


	if(isset($_POST["submit"]))
	{
		$korime = $_POST["korime"];
		$lozinka = $_POST["lozinka"];
		if(isset($korime) && isset($lozinka) && !empty($korime) && !empty($lozinka))
		{
			
			
			
			$upit="SELECT * FROM korisnik WHERE korisnicko_ime='".$korime."' AND lozinka='".$lozinka."'";
			$rezultat=izvrsiUpit($veza,$upit);
			$profil=mysqli_fetch_array($rezultat);
			print_r($profil);
			if ($profil ['korisnicko_ime']== $korime && $profil['lozinka']== $lozinka)
			{
				if ($profil ['tip_korisnika_id'] == 3)
					{
					setcookie("id_korisnika",$profil['korisnik_id']);
					setcookie("tip",$profil ['tip_korisnika_id']);
					header ("Location:korisnik_r.php");
					}
				if ($profil ['tip_korisnika_id'] == 2 )
				{
					setcookie("id_korisnika",$profil['korisnik_id']);
					setcookie("tip",$profil ['tip_korisnika_id']);
					header ("Location:moderator.php");
				}
				if ($profil ['tip_korisnika_id'] == 1)
				{
					setcookie("id_korisnika",$profil['korisnik_id']);
					setcookie("tip",$profil ['tip_korisnika_id']);
					header ("Location:admin.php");
				}	
			}
			else
			{
				$greska = "Kombinacija korisničkog imena i lozinke nije valjana";
			}
		}
		else
			{
				$greska = "Kombinacija korisničkog imena i lozinke nije valjana";
			}
			
		zatvoriVezuNaBazu($veza);
			
			
	}
	

?>




<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8" />
    <title>Prijava</title>
	<link href="stil_nav.css"  rel="stylesheet" type="text/css" />
	<link href="stil_inputa.css"  rel="stylesheet" type="text/css" />
	<style>
	form
	{
	position:absolute;
	top:40%;
	left:45%;
	width:13.5%;
	}
	h1 
	{
	position:absolute;
	top:25%;
	left:45%;
	font-family:arial;
	font-weight:normal;
	width:13.5%;
	text-align:center;
	}
	
	
	</style>
	
</head>
 
<body>
	<header>
        <nav>
            <ul>

                <li>
                    <a href="o_autoru.html">O autoru</a>
                </li>
                <li>
                    <a href="prijava.php">Prijava</a>
                </li>
		<li>
                    <a href="index.php " >Index</a>
                </li>
				<?php echo $moderator;?>
                
				<?php echo $kor_nav;?>
				
				<?php echo $admin;?>
				
				
				

            </ul>
        </nav>
		
</header>
		
	<h1>PRIJAVI SE</h1>
	<form style="" id="prijava" action="<?php echo $_SERVER["PHP_SELF"]?>" name="prijava" method="POST"  >
	<label for "korime">Korisničko ime </label>
	<input name="korime" type="text"/>
	<label for "lozinka">Lozinka</label>
	<input name ="lozinka" type="password">
	<br><input name="submit" id="submit" type="submit" value="Prijavi" />
	<div style="color:red;" >
			<?php
				if(isset($greska)){
					echo $greska;
				}
			?>
			</div>

</body>
</html>