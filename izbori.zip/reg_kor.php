<?php


include "nav.php";
if (empty($_COOKIE))
	header ("Location: index.php");
if ($tip==4)
	header ("Location: prijava.php");


if (isset($_POST["kandidirajse"])) 
	{
		if (isset($_POST ['izbor'])){
			$id_izbora=$_POST ['izbor'];		
			header("Location:kandidirajse.php?id_izbora=".$id_izbora);
		}
	}



include "baza.php";
$veza = SpojiSeNaBazu();
$upit="SELECT * FROM izbor WHERE datum_vrijeme_zavrsetka > now() ORDER BY datum_vrijeme_zavrsetka DESC";
$rezultat=izvrsiUpit($veza,$upit);
$izbor="";
$kandidat="";
$kand_izbor="";
$porukakandidatura="";
$id_korisnika = $_COOKIE ["id_korisnika"];

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Korisni</title>
	<link href="stil_nav.css"  rel="stylesheet" type="text/css" />
	<link href="stil_inputa.css"  rel="stylesheet" type="text/css" />
	<style>
	form
	{
	overflow:scroll;
	position:absolute;
	top:40%;
	left:19.99%;
	width:59.8%;
	border:2px solid #ccc; 
    border-radius: 5px;
	background:white;
	font-size:20px;
	}
	h1 
	{
	position:absolute;
	top:25%;
	width:59.8%;
	left:19.99%;
	font-family:arial;
	font-weight:normal;
	width:19%;
	text-align:center;
	}
	#naslov2
	{
	top:110%;	
	}
	#kandidatura{
		float:left;
	}
	#gumb1
	{
	margin:2%;
	float:right;
	}
	input[type=submit]:hover{background:#fbfb4a}
	#odjava
	{
			color: chocolate;
            text-decoration: none;
			border-radius: 30px;
			text-align: center;
			border:0px;
			transition:1s;
			font-size:20px;
	}
	
	</style>

</head>
<body>
    <header>
        <nav>
            <ul>

                <li>
                    <a href="o_autoru.html">O autoru</a>
                </li>
             
                <li>
                    <a href="reg_kor.php">Korisnik</a>
                </li>
				<li>
                    <a href="index.php">Index</a>
                </li>
				
                    <?php echo $moderator;?>
                
				
				
					<?php echo $admin;?>
				

            </ul>
        </nav>
    </header>
	<div><a id="odjava" style="margin-left:3%; top:25% ;position: absolute;" href="odjava.php">Odjavi se</a></div>
<h1 style="width:59.99%">Odaberite izbor za glasanje ili kandidiranje</h1>
<h1 id="naslov2" style="width:59.99%">Izbori za koje ste se kandidirali</h1>
<form action="<?php echo $_SERVER["PHP_SELF"]?>" name="kandidat" method="POST" style="top:123%">

<?php 


if (isset($_POST["kandidatura"]) && isset($_POST["kand_izbor"]))
{
	
	
	$kandidat_id1= $_POST['kand_izbor'];
	$upit_kandidatura="UPDATE kandidat SET status = 'O' WHERE kandidat_id ='$kandidat_id1'";
	$rez_kandidatura=izvrsiUpit($veza,$upit_kandidatura);
	
	
}

$upit_kandidat = "SELECT * FROM kandidat JOIN izbor ON kandidat.izbor_id = izbor.izbor_id where korisnik_id ='$id_korisnika' and status='K'";
$kandidirani_izbori=izvrsiUpit($veza,$upit_kandidat);

$poruka_kand="";
$kand_izbor="";

while ($red1=mysqli_fetch_array($kandidirani_izbori))
{	
	
	$kand_izbor="<br>". $kand_izbor. "<input name ='kand_izbor' type='radio' value=".$red1['kandidat_id'].">"."<strong>   Naziv:  </strong>".$red1["naziv"]."   <strong>Datum završetka:   </strong>" .$a=date("d.m.Y.",strtotime( $red['datum_vrijeme_zavrsetka']))."    <strong>Opis:    </strong>" .$red1["opis"]."<br><br>";
	
	
}
if (!empty($kand_izbor))
	echo $kand_izbor;
else echo "Nemate aktivnih kandidatura";

$gumbkandidatura = '<input name="kandidatura" id="kandidatura" type="submit" value="Povuci kandidaturu" /><BR><BR>';






?>
<p><?php if(!empty($poruka_kand))echo $poruka_kand;?></p>
<div id="gumb1"><?php  echo $gumbkandidatura; ?></div>
</form>


<div style ="position:absolute; top:67%"><?php  echo $porukakandidatura;  ?></div>
<br><br>

<form action="<?php echo $_SERVER["PHP_SELF"]?>" name="grad" method="POST" style ="position:absolute; height:70%" >

<?php

while($red = mysqli_fetch_array($rezultat)){
	$izbor.="<input name='izbor' type='radio' value= ".$red['izbor_id'].">"."<strong>   Naziv:  </strong>".$red["naziv"]."   <strong>Datum završetka:   </strong>" .$a=date("d.m.Y. h:i:s",strtotime( $red['datum_vrijeme_zavrsetka']))."    <strong>Opis:  </strong>" .$red["opis"]."<br><br>";
	
}
echo $izbor;
echo '<input style="float:right; margin:2%;" name="submit_izbor1"  id="submi_izbor" type="submit" value="Glasaj" />    ';
echo '<input style="float:right; margin:2%;" name="kandidirajse" id="submi_kandidata" type="submit" value="Kandidiraj se" /> ';

	
	
	
	


if(isset($_POST["submit_izbor1"])) 
	{
		$id_izbora=$_POST ['izbor'];
		
		
		$upit="select * from kandidat join korisnik on kandidat.korisnik_id=korisnik.korisnik_id WHERE izbor_id='$id_izbora'";
		$rezultat3=izvrsiUpit($veza,$upit);
		$kandidati="";
		
		
		echo '<br><br><h2 style="text-align:center">Odaberite kandidata</h2><br>';
		while($red = mysqli_fetch_array($rezultat3))
		{
			
			if ($red['status']== "K")
			$kandidat="<br>".$kandidat. "<input name='izbor' type='radio' value=".$red['izbor_id']." >". "<strong>Ime:  </strong>".$red["ime"]."   <strong>Prezime:   </strong>".$red["prezime"] . "    <strong>Email:    </strong>".$red["email"]."    <strong>Video:</strong><video width='320' height='240' controls> <source src='".$red['video']."' type='video/mp4'> </video><br>";	
				
		}
		echo $kandidat;
		echo '<input style="float:right; margin:2%;" name="submit_kandidata" id="submi_kandidata" type="submit" value="Odaberi" />';
		
	}
if (isset($_POST["submit_kandidata"]))	
	{
		$kandidat_id= $_POST ['izbor'];
                $upit2= "SELECT * FROM glas join kandidat on glas.kandidat_id=kandidat.kandidat_id where glas.korisnik_id='$id_korisnika'";
		$rez=izvrsiUpit($veza,$upit2);
                $provjera=array();
		
		while ($red = mysqli_fetch_array($rez))
                {
                    $provjera[]=$red['izbor_id'];
                        
                }
		print_r($provjera);
                print_r($id_izbora);
                
                foreach ($provjera as $k=>$v)
                    {
                        if ($v = $izborglasa_id)
                                {
                                    $P="1";
                                }
                              
                    }
                    
                        
		
		if (empty($P))
		{
			$upit3="INSERT INTO glas VALUES('$id_korisnika','$kandidat_id') ";
			$rezultat4=izvrsiUpit($veza,$upit3);
			echo "<div style='color:green'><strong>Glasanje uspješno</strong></div>";
		}
		else echo "<div style='color:red'><strong>Već ste glasali na odabranim izborima</strong></div>";
	}

		
	zatvoriVezuNaBazu($veza);
?>


<br>
<br>
<br>

</form>
</body>
</html>