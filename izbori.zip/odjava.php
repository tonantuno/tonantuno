<?php

    unset($_COOKIE['tip']);
    setcookie('tip', null, -1);
    header('Location: prijava.php');

?>

