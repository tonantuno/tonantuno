<?php
if (empty($_COOKIE))
    header("Location: index.php");
if ($_COOKIE["tip"] != 1)
    header("Location: prijava.php");

include "nav.php";
include "baza.php";
$veza = SpojiSeNaBazu();

$upit = "select * from korisnik join tip_korisnika on korisnik.tip_korisnika_id = tip_korisnika.tip_korisnika_id";
$korisnikobjekt = izvrsiUpit($veza, $upit);


$upit_tip = "select * from tip_korisnika";
$tipovi_objekt = izvrsiUpit($veza, $upit_tip);
$tip = "";

while ($red = mysqli_fetch_array($tipovi_objekt)) {
    $tip = $tip . "<option value = " . $red["tip_korisnika_id"] . ">" . $red['naziv'] . "</option>";
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" />
        <title>Admin</title>
        <link href="stil_nav.css"  rel="stylesheet" type="text/css" />
        <link href="stil_inputa.css"  rel="stylesheet" type="text/css" />
        <style>
            form
            {
                margin-left:auto;
                margin-right:auto;
                width:30%;
            }
            h2{
                margin-top:5%;
                width:100%;
                text-align:center;
            }
            #azur_kor
            {
                margin-top:20%;
            }
            #kor
            {
                text-decoration:none;
                font-weight:bold;
                color:#ff8300;
            }
            #kor:hover
            {
                color:#6400ff
            }
            #mjesto{margin-top:10%}
            input[type=submit]
            {
                margin-bottom: 2%;
                margin-left: 31%;
                float: left;
            }
            #odjava
            {
                color: chocolate;
                text-decoration: none;
                border-radius: 30px;
                text-align: center;
                border:0px;
                transition:1s;
                font-size:20px;
            }
            #filter_gumb{
                background:#ccc;
                border:5px solid #ccc;
                border-radius:5px;
                margin-top:0%;
                margin-bottom:4%;
                color:white;
                text-decoration:none;
                font-family:arial;
                font-size:20px;
                font-weight:bold;
                position:absolute;
                top:25%;
                left:55%;
                padding:10px;
            }
            #kor_gumb{
                background:#ccc;
                border:5px solid #ccc;
                border-radius:5px;
                margin-top:0%;
                margin-bottom:4%;
                color:white;
                text-decoration:none;
                font-family:arial;
                font-size:20px;
                font-weight:bold;
                position:absolute;
                top:25%;
                left:25%;
                padding:10px;
            }
            #filter_gumb:hover{background:#fbfb4a;border-color:#fbfb4a}
            #kor_gumb:hover{background:#fbfb4a;border-color:#fbfb4a}
        </style>
    </head>
    <body>
        <header>
            <nav>
                <ul>

                    <li>
                        <a href="o_autoru.html">O autoru</a>
                    </li>

                    <li>
                        <a href="korisnik_r.php">Korisnik</a>
                    </li>
                    <li>
                        <a href="index.php">Index</a>
                    </li>

<?php echo $moderator; ?>



<?php echo $admin; ?>


                </ul>
            </nav>
        </header>
        <a id="odjava"  style="margin-left:3%; top:25% ;position: absolute;" href="odjava.php">Odjavi se</a>
        <a href="filtriranje_sortiranje.php" id="filter_gumb">Filtriranje/sortiranje izbora</a>
        <a href="registracija.php" id="kor_gumb">Unesite/registrirajte korisnika</a>

        <table align="center" id="azur_kor" border="1px" >
            <tr>
                <th colspan ="4" <h2>AŽURIRAJ KORISNIKA</h2></th>
            </tr>
            <tr>
                <th>Ime</th>
                <th>Prezime</th>
                <th>email</th>
                <th>Tip korisnika</th>
            </tr>
<?php
while ($red = mysqli_fetch_array($korisnikobjekt)) {
    ?>

                <tr>
                    <td><a id="kor" href="azuriranje_korisnika.php?korisnik_id=<?php echo $red['korisnik_id'] ?>"><?php echo $red['ime']; ?></a></td> 
                    <td><?php echo $red['prezime']; ?></td>
                    <td><?php echo $red['email']; ?></td>
                    <td><?php echo $red['naziv']; ?></td>
                </tr>



    <?php
}
?>

        </table>
                    <?php
                    $upitmjesto = "select * from izborno_mjesto";
                    $mjestoobjekt = izvrsiUpit($veza, $upitmjesto);
                    ?>	


                <table id="mjesto" align="center" border="1px" >
                    <tr>
                        <th colspan ="2" <h2>AŽURIRANJE IZBORNIH MJESTA</h2></th>
                    </tr>
                    <tr>
                        <th>Naziv</th>
                        <th>Opis</th>
                    </tr>
                <?php
                while ($red1 = mysqli_fetch_array($mjestoobjekt)) {
                    ?>

                        <tr>
                            <td><a id="kor" href="azuriranje_mjesta.php?mjesto_id=<?php echo $red1['izborno_mjesto_id'] ?>"><?php echo $red1['naziv']; ?></a></td> 
                            <td><?php echo $red1['opis']; ?></td>

                        </tr>



                        <?php
                    }
                    ?>

                </table>


<?php
$upit_moderator = "select * from korisnik where tip_korisnika_id = '2'";
$moderator_objekt = izvrsiUpit($veza, $upit_moderator);
$moderator = "";

while ($red5 = mysqli_fetch_array($moderator_objekt)) {
    $moderator = $moderator . "<option value = " . $red5['korisnik_id'] . ">" . $red5['ime'] . "   " . $red5['prezime'] . "</option>";
}
?>


                <h2>Unesi mjesto izbora<h2>
                        <form action="<?php echo $_SERVER["PHP_SELF"] ?>" name="unos_mjesta" method="POST">

                            <br>
                            <label for ="tip">Odaberite moderatora</label>
                            <br>
                            <select name="moderator">
                <?php echo $moderator; ?>
                            </select>
                            <br>
                            <label for="ime">Grad</label>
                            <br>
                            <input name="naziv" type="text" >
                            <br>
                            <label for="prezime">Opis</label>
                            <br>
                            <input name="opis" type="text" >
                            <br>                 
                            <br>
                            <input id="submit" name="submitmjesto" type="submit" value="Unesi" >
                            <br>
<?php
if (isset($_POST['submitmjesto'])) {




    $moderator = $_POST['moderator'];
    $naziv = strtoupper($_POST['naziv']);
    $opis = $_POST['opis'];




    $upit_mjesto = "insert into izborno_mjesto  values (default, '$moderator', '$naziv', '$opis'    ) ";
    izvrsiUpit($veza, $upit_mjesto);
}
?>
                        </form>
                        </body>
                        </html>