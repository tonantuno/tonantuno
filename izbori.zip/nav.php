<?php 
$moderator="";
$admin="";
$kor_nav="";
$tip=4;

if (isset($_COOKIE['tip']))
{
	$tip=$_COOKIE['tip'];
if ($tip<=2){$moderator='<li><a href="moderator.php">Moderator</a></li>';}
if ($tip==1){$admin='<li><a href="admin.php">Admin</a></li>';}
if ($tip<=3){$kor_nav='<li><a href="korisnik_r.php">Korisnik</a></li>'; }
}
?>