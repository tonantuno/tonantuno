<?php 
include "baza.php";
include "nav.php";
if ($tip==4)
	header ("Location: prijava.php");
if (empty($_COOKIE))
	header ("Location: index.php");
if ($_COOKIE["tip"] == 3 )
	header ("Location: prijava.php");
$veza = SpojiSeNaBazu();
$id_izbora= $_GET['izbor_id'];

if (isset($_POST['submit']))
{
	$id_izbora= $_GET['izbor_id'];
        $input_datum=$_POST['datum_pocetka'];
	
	$vrijeme_pocetka=$_POST['vrijeme_pocetka'];
	$noviDatum= date('Y-m-d',strtotime($input_datum));
        
        
        
	$noviNaziv=$_POST['naziv'];
	$noviDatum1=$noviDatum." ".$vrijeme_pocetka;
	$noviOpis=$_POST['opis'];
	
	$datum_zavrsetka= date( "Y-m-d", strtotime( "$noviDatum +7 day" ));
	$datum_zavrsetka= $datum_zavrsetka." ".$vrijeme_pocetka;
	
	$upitunos="update izbor set naziv='$noviNaziv', datum_vrijeme_pocetka ='$noviDatum1', datum_vrijeme_zavrsetka='$datum_zavrsetka', opis='$noviOpis' where izbor_id ='$id_izbora' ";
	
	$rez12=izvrsiUpit($veza,$upitunos);
}







$upit = "select * from izbor join izborno_mjesto on izbor.izborno_mjesto_id = izborno_mjesto.izborno_mjesto_id where izbor_id = '$id_izbora'";
$rez=izvrsiUpit($veza,$upit);

$naziv = mysqli_fetch_array($rez);



	$lista_datum = explode(" ", $naziv['datum_vrijeme_pocetka']);
	$datum=date("d.m.Y.",strtotime( $lista_datum[0]));
	$vrijeme=$lista_datum[1];

	$naziv1= $naziv[2];
	$opis = $naziv[5];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />

    <title>Ažuriranje izbora</title>
	<link href="stil_nav.css"  rel="stylesheet" type="text/css" />
        <link href="stil_inputa.css"  rel="stylesheet" type="text/css" />
	<style>
	form
	{
	position:absolute;
	top:40%;
	left:33%;
	width:30%;
	height:70%;
	margin-top:3%;
	
	}
	h1 
	{
	position:absolute;
	top:25%;
	left:33%;
	font-family:arial;
	font-weight:normal;
	width:30%;
	height:80%;
	text-align:center
	}
	#submit{float:left; margin-top:1%}
	textarea{
		padding:5px; 
		border:2px solid #ccc; 
		border-radius: 5px;
		width:100%;
	}
	#l{width:100%}
	</style>
</head>
<body>
<header>
        <nav>
            <ul>

                <li>
                    <a href="o_autoru.html">O autoru</a>
                </li>
             
                <li>
                    <a href="korisnik_r.php">Korisnik</a>
                </li>
				<li>
                    <a href="index.php">Index</a>
                </li>
				
                    <?php echo $moderator;?>
                
				
				
					<?php echo $admin;?>
				

            </ul>
        </nav>
    </header>
<h1>Ažuriranje izbora <?php echo " u gradu: "." " .$naziv['naziv'] ?></h1>
<form action="azuriranje_izbor.php?izbor_id=<?php echo $id_izbora ?>" name="unos_izbor" method="POST">
    <br>
	<label id="l"for="naziv">Naziv</label>
        <br>
	<input id="l" name="naziv" type="text" value="<?php echo $naziv1?>">
        <br>
	
	<label id="l" for="datum_pocetka">Datum početka</label>
        <br>
	<input id="l" name="datum_pocetka" type="text" placeholder ="dd-mm-gggg" value="<?php echo $datum?>"><br>
	
	<label id="l" for="vrijeme_pocetka">Vrijeme početka</label>
        <br>
	<input id="l" name="vrijeme_pocetka" type="text" placeholder ="hh:mm:ss" value="<?php echo $vrijeme?>">
        <br>
	

	
	
	<label for="opis">Opis</label>
        <br>
        <input maxlength="100" size="59" name="opis" type="text" value="<?php echo $opis?>">
        <br>
	<input id="submit" name="submit" type="submit" value="Unesi izbor">




</form>
</body>
</html>