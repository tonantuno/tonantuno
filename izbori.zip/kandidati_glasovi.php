<?php


include "nav.php" ;
include "baza.php";
if ($tip==4)
	header ("Location: prijava.php");
if (empty($_COOKIE))
	header ("Location: index.php");
if ($_COOKIE["tip"] == 3 )
	header ("Location: prijava.php");
$veza = SpojiSeNaBazu();
$id_izbora= $_GET['izbor_id'];

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
    <title>Ažuriranje izbora</title>
	<link href="stil_nav.css"  rel="stylesheet" type="text/css" />
	<link href="stil_inputa.css"  rel="stylesheet" type="text/css" />
	<style>
	table{
		margin-top:15%;
		text-align:center;
		
	}
	
	</style>
<head>
<body>
<header>
        <nav>
            <ul>

                <li>
                    <a href="o_autoru.html">O autoru</a>
                </li>
             
                <li>
                    <a href="korisnik_r.php">Korisnik</a>
                </li>
				<li>
                    <a href="index.php">Index</a>
                </li>
				
                    <?php echo $moderator;?>
                
				
				
					<?php echo $admin;?>
				

            </ul>
        </nav>
    </header>
	<table  border="1px" align="center" >
	<tr>
		<th colspan ="3"><h1 id="azuriranje">Statistika glasova</h1></th>
	</tr>
	<tr>
		<th>Kandidat</th>
		<th>Broj glasova</th>
		<th>Postotak</th>
	</tr>
<?php
$upit_sveukupni_broj="SELECT COUNT(*) FROM `korisnik` JOIN kandidat ON kandidat.korisnik_id=korisnik.korisnik_id JOIN glas ON glas.kandidat_id=kandidat.kandidat_id 	WHERE izbor_id= '$id_izbora'";
$sveukupni_glasovi=izvrsiUpit($veza,$upit_sveukupni_broj);
$sveukupni_glasovi=mysqli_fetch_array($sveukupni_glasovi);
$sveuk=$sveukupni_glasovi['COUNT(*)'];



$kandidat="";

$upit= "select * from korisnik join kandidat on kandidat.korisnik_id = korisnik.korisnik_id where izbor_id = '$id_izbora'";
$rez=izvrsiUpit($veza,$upit);
while ($red=mysqli_fetch_array($rez)){
$kandidat = $red ['ime'] ." ". $red ['prezime']." ".$red ['email']. "<br><br>" ;
$id_kandidata = $red ['kandidat_id'];
$upit_glas = "select COUNT(*) from glas where kandidat_id = '$id_kandidata' ";
$broj_glas=izvrsiUpit($veza,$upit_glas);
$broj = mysqli_fetch_array ($broj_glas);



$glas=$broj['COUNT(*)'];
$decimal = $glas / $sveuk;
$postotak = number_format( $decimal * 100, 1 ) . '%'."<br><br>";

?>
<tr>
		<td><?php echo $kandidat;?></td>
		<td><?php echo $broj['COUNT(*)'];?></td>
		<td><?php echo $postotak;?></td>
	</tr>


<?php
}

zatvoriVezuNaBazu($veza);


?>
</body>
</html>