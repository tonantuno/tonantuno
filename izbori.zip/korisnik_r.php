<?php
include "nav.php";
include "baza.php";
$veza = SpojiSeNaBazu();
if (empty($_COOKIE))
    header("Location: index.php");
if ($tip == 4)
    header("Location: prijava.php");

$id_korisnika = $_COOKIE ["id_korisnika"];

if (isset($_POST['submit123'])){
        $kandidat_id1= $_POST['kand_izbor'];
	$upit_kandidatura="UPDATE kandidat SET status = 'O' WHERE kandidat_id ='$kandidat_id1'";
	$rez_kandidatura=izvrsiUpit($veza,$upit_kandidatura);

}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" />
        <title>Korisni</title>
        <link href="stil_nav.css"  rel="stylesheet" type="text/css" />
        <link href="stil_inputa.css"  rel="stylesheet" type="text/css" />
        <style>
         
            table{
                border: 1px solid #CCCCCC;
                border-radius: 6px 6px 6px 6px;
                border-radius: 6px 6px 6px 6px;
                border-radius: 6px 6px 6px 6px;
                box-shadow: 0 1px 1px #CCCCCC;
                border-spacing: 0;
                font-size:20px;
                margin-top: 20%;
                z-index:10;
                margin-left:auto;
                margin-right:auto;
            }
            a{
                text-decoration: none;
            }
            a:hover{
                color:orange;
            }
            caption{
                font-weight: bold;
                font-size:30px;
            }
            form{
                height:280px;
                overflow: scroll;
                width:65%;
                margin-top: 3%;
                margin-left: auto;
                margin-right: auto;
            }
            h1{font-weight: bold;
                font-size:30px;
            text-align: center;}
            input[type=submit]:hover{background:#fbfb4a}
        </style>

    </head>
    <body>

        <header>
            <nav>
                <ul>

                    <li>
                        <a href="o_autoru.html">O autoru</a>
                    </li>

                    <li>
                        <a href="korisnik_r.php">Korisnik</a>
                    </li>
                    <li>
                        <a href="index.php">Index</a>
                    </li>
                   

<?php echo $moderator; ?>



<?php echo $admin; ?>


                </ul>
            </nav>
        </header>
        <a id="odjava" style="margin-left:3%; top:25% ;position: absolute;" href="odjava.php">Odjavi se</a>

        
<?php
$upit = "SELECT * FROM izbor WHERE datum_vrijeme_zavrsetka > now() ORDER BY datum_vrijeme_zavrsetka DESC";
$rezultat = izvrsiUpit($veza, $upit);
print "
    <table border='1px'>
    <caption>POPIS AKTIVNIH IZBORA</caption>
    
        <tr>
        <th>Naziv izbora</th>
        <th>Datum završetka</th> 
        <th>Opis</th>
        </tr>";


while ($red = mysqli_fetch_array($rezultat)) {
    $a = date("d.m.Y.", strtotime($red['datum_vrijeme_pocetka']));
    print "<tr><td><strong><a href='glasanje.php?id_izbora=".$red['izbor_id']."'>" . $red['naziv'] . "</a></strong></td><td>" . $a . "</td><td>" . $red['opis'] . "</td>";
}
print "</table>";
?>
    <h1>IZBORI ZA KOJE STE SE KANDIDIRALI</h1>
<form action="korisnik_r.php" name="grad" method="POST" >
    <?php  
$upit_kandidat = "SELECT * FROM kandidat JOIN izbor ON kandidat.izbor_id = izbor.izbor_id where korisnik_id ='$id_korisnika' and status='K'";
$kandidirani_izbori=izvrsiUpit($veza,$upit_kandidat);

$kand_izbor="";
while ($red1=mysqli_fetch_array($kandidirani_izbori))
{	
	
	$kand_izbor="<br>". $kand_izbor. "<div><input name ='kand_izbor' type='radio' value=".$red1['kandidat_id'].">"."<strong>   Naziv:  </strong>".$red1["naziv"]."   <strong>Datum završetka:   </strong>" .$a=date("d.m.Y.",strtotime( $red['datum_vrijeme_zavrsetka']))."    <strong>Opis:    </strong>" .$red1["opis"]."</div>";
	
	
}
print'<input type="submit" value="Povuci kandidaturu" name="submit123"/>';

if (!empty($kand_izbor))
	echo $kand_izbor;
else echo "<div>Nemate aktivnih kandidatura</div>";



?>
</form>
</body>