<?php 
include "baza.php";
include "nav.php";
$veza = SpojiSeNaBazu();
if ($tip==4)
	header ("Location: prijava.php");
if (empty($_COOKIE))
	header ("Location: index.php");


?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Korisni</title>
	<link href="stil_nav.css"  rel="stylesheet" type="text/css" />
	<link href="stil_inputa.css"  rel="stylesheet" type="text/css" />
	<style>
	
	textarea
	{
		 padding:5px; 
    border:2px solid #ccc; 
    border-radius: 5px;
	}
	h1
	{
		font-weight:normal;
		font-family:arial;
		font-size:30px;
		margin-right:auto;
		margin-left:auto;
		margin-top:12%;
		text-align:center;
		
	}
	form
	{
		top:30%;
		margin-right:auto;
		margin-left:auto;
		text-align:center;
	}
	input[type=submit]
	{
		margin-right:33%;
	}
	p{
		margin-left:30%;
		margin-right:auto;
		forn-size:20px;
		color:red;
		
	}
	
	</style>
</head>

<body>
<header>
        <nav>
            <ul>

                <li>
                    <a href="o_autoru.html">O autoru</a>
                </li>
             
                <li>
                    <a href="korisnik_r.php">Korisnik</a>
                </li>
				<li>
                    <a href="index.php">Index</a>
                </li>
				
                    <?php echo $moderator;?>
                
				
				
					<?php echo $admin;?>
				

            </ul>
        </nav>
</header>
    

<h1>Obrazac za kandidaturu</h1>
<form action="<?php echo $_SERVER["PHP_SELF"] . "?id_izbora=" . $_GET['id_izbora']; ?>" name="kandidirajse" method="POST">

<label for="zivotopis">Životopis</label><br>
	<textarea required name="zivotopis" id="zivotopis" rows="10" cols="60" maxlength="1000" placeholder="Životopis" > </textarea>
<br>			
<label for="video">Video</label><br>
	<input required type="text" name="video" id="video" size="59" placeholder="Video URL" >
<br><br>
<input name="submit" id="submit" type="submit" value="Kandidiraj se">

<?php 

$id_korisnika = $_COOKIE['id_korisnika'];
$id_izbora = $_GET['id_izbora'];
$provjera = "select * from kandidat where korisnik_id='$id_korisnika' and izbor_id='$id_izbora'";
$rezprovjera=izvrsiUpit($veza,$provjera);
$rez1=mysqli_fetch_array($rezprovjera);
if (empty($rez1))
{
	
	
	
	
	if (!empty ($_POST['zivotopis']) && !empty($_POST['video']))
		{
		
		$zivotopis = $_POST['zivotopis'];
		$video = $_POST ['video'];
	
		$upit = "INSERT INTO kandidat VALUES (default, '$id_korisnika','$id_izbora','$zivotopis','$video', 'K' )";
		$rez=izvrsiUpit($veza,$upit);
		echo "<p>Kandidirali ste se!</p>";
		}
	else "<p>Životopis ili video link ste izostavili!</p>";
	

	
	
	
}
else
{
echo "<p>Već ste se kandidirali jednom za ovaj izbor!<p>";
}

?>

</form>

</body>

</html>