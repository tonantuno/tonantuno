<?php
if (empty($_COOKIE))
	header ("Location: index.php");
if ($_COOKIE["tip"] != 1 )
	header ("Location: prijava.php");
include "nav.php";
include "baza.php";
$veza = SpojiSeNaBazu();
$korisnik_id= $_GET['korisnik_id'];
$greska="";



if (isset($_POST['submit']))
{
	$korisnik_id= $_GET['korisnik_id'];
	
	
	$novIme=$_POST['ime'];
	$novPrezime=$_POST['prezime'];
	$novEmail=$_POST['email'];
	$novSlika="korisnici/" . $_FILES["slika"]["name"];
	$novKorime=$_POST['korime'];
	$novLozinka=$_POST['lozinka'];
	$tip=$_POST['tip'];
        
        
        $provjera = $_FILES["slika"]["size"];
        if ($provjera > 524288) {
        $greska .= "Slika zauzima više od 0.5 MB";
        }
        
        $tipdat = strtolower(pathinfo($novSlika, PATHINFO_EXTENSION));

        if (!($tipdat === "jpg" || $tipdat === "png")) {
        $greska .= "Slika nije jpg ili png";
        }
        
        if (empty($greska)){
            
            $upitazuriranje="update korisnik set ime='$novIme', prezime ='$novPrezime', email='$novEmail', slika='$novSlika', korisnicko_ime='$novKorime', lozinka='$novLozinka', tip_korisnika_id='$tip' where korisnik_id ='$korisnik_id' ";
            move_uploaded_file($_FILES["slika"]["tmp_name"], $novSlika);
            $rez12=izvrsiUpit($veza,$upitazuriranje);
        }
        
         

	
}

$upit_kor_tip="select tip_korisnika_id from korisnik where korisnik_id='$korisnik_id'";
$dohvati_tip=izvrsiUpit($veza,$upit_kor_tip);
$tip_kor_a=mysqli_fetch_array($dohvati_tip);
$tip_kor=$tip_kor_a[0];

$upit_tip= "select * from tip_korisnika";
$tipovi_objekt=izvrsiUpit($veza,$upit_tip);
$tip="";
while($red = mysqli_fetch_array($tipovi_objekt))
		{
			if ($tip_kor==$red['tip_korisnika_id'])
				$tip = $tip . "<option selected value = ".$red["tip_korisnika_id"]. " >".$red['naziv']."</option>";
			else
			$tip = $tip . "<option value = ".$red["tip_korisnika_id"]. ">".$red['naziv']."</option>";
		
		}


$upitzainput="select * from korisnik where korisnik_id = '$korisnik_id'";
$upitbaza=izvrsiUpit($veza,$upitzainput);
$upitulistu = mysqli_fetch_array($upitbaza);

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
    <title>Admin</title>
	<link href="stil_nav.css"  rel="stylesheet" type="text/css" />
	<link href="stil_inputa.css"  rel="stylesheet" type="text/css" />
	<style>
	form
	{
	margin-left:auto;
	margin-right:auto;
	width:15%;
	margin-top:3%;
	}
	h1{
	margin-top:13%;
	width:100%;
	text-align:center;
	}
	#submit{float:left}
        #greska{
            color:red;
            text-align:center;
            font-size:30px;
          
            margin-top: 2%;
        }
	</style>
        
<body>
<header>
        <nav>
            <ul>

                <li>
                    <a href="o_autoru.html">O autoru</a>
                </li>
             
                <li>
                    <a href="korisnik_r.php">Korisnik</a>
                </li>
				<li>
                    <a href="index.php">Index</a>
                </li>
				
                    <?php echo $moderator;?>
                
				
				
					<?php echo $admin;?>
				

            </ul>
        </nav>
    </header>

<h1>Ažuriranje korisnika</h1>
	<form action="azuriranje_korisnika.php?korisnik_id=<?php echo $korisnik_id ?>" name="unos_izbor" method="POST" enctype="multipart/form-data">
	
        <br>
	<label for ="tip">Odaberite tip korisnika</label>
        <br>
	<select name="tip">
		<?php echo $tip;?>
	</select>
        <br>

	
	<label for="ime">Ime</label>
        <br>
	<input name="ime" type="text" value="<?php echo $upitulistu['ime']; ?>" >
        <br>
	
	<label for="prezime">Prezime</label>
        <br>
	<input name="prezime" type="text" value="<?php echo $upitulistu['prezime']; ?>" >
        <br>
	
	<label for="prezime">Email</label>
        <br>
	<input name="email" type="text" value="<?php echo $upitulistu['email']; ?>" >
        <br>
	<label for="slika">Slika</label>
        <br>
        <img src="<?php echo $upitulistu['slika']; ?>"  height="400px" width="300px">
	<input name="slika" type="file" id="uploadslike"/>
        <br>
	<label for="korime">Korisnicko ime</label>
        <br>
	<input name="korime" type="text" value="<?php echo $upitulistu['korisnicko_ime']; ?>" >
        <br>
	<label for="lozinka">Lozinka</label>
        <br>
	<input name="lozinka" type="text" value="<?php echo $upitulistu['lozinka']; ?>" >
        <br>	
        <input id="submit" name="submit" type="submit" value="Ažuriraj korisnika" >
        <br>
        </form>
<?php

        echo "<div id='greska'>".$greska."</div>";
        
?>
</body>
</html>