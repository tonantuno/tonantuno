<?php
if (empty($_COOKIE))
    header("Location: index.php");
if ($_COOKIE["tip"] != 1)
    header("Location: prijava.php");
include "nav.php";
include "baza.php";
$veza = SpojiSeNaBazu();




if (isset($_POST["submit"])) {
    $korime = $_POST["korime"];
    $lozinka = $_POST["lozinka"];
    $potvrdaloz = $_POST ["potvrdaloz"];
    $ime = $_POST["ime"];
    $prezime = $_POST["prezime"];
    $email = $_POST["email"];
    $slika = "korisnici/" . $_FILES["slika"]["name"];
    $tip = $_POST['tip'];
    $greska = "";
    if (!isset($korime) || empty($korime)) {
        $greska .= "Unesite korisničko ime!<br>";
    }
    if (!isset($lozinka) || empty($lozinka)) {
        $greska .= "Unesite lozinku!<br>";
    }
    if (!isset($potvrdaloz) || empty($potvrdaloz)) {
        $greska .= "Unesite potvrdu lozinke!<br>";
    }
    if ($lozinka !== $potvrdaloz) {
        $greska .= "Potvrda lozinke nije točna<br>";
    }
    if (!isset($ime) || empty($ime)) {
        $greska .= "Unesite ime! <br>";
    }
    if (!isset($prezime) || empty($prezime)) {
        $greska .= "Unesite prezime!<br>";
    }
    if (!isset($email) || empty($email)) {
        $greska .= "Unesite email!<br>";
    }
    $provjera = $_FILES["slika"]["size"];

    if ($provjera > 524288) {
        $greska .= "Slika zauzima više od 0.5 MB";
    }
    $tipdat = strtolower(pathinfo($slika, PATHINFO_EXTENSION));

    if (!($tipdat === "jpg" || $tipdat === "png")) {
        $greska .= "Slika nije jpg ili png";
    }

    if (empty($greska)) {

        $provjera = "select korisnicko_ime from korisnik where korisnicko_ime='$korime'";
        $provjerabaza = izvrsiUpit($veza, $provjera);
        $ispis = mysqli_fetch_array($provjerabaza);

        if (empty($ispis)) {

            move_uploaded_file($_FILES["slika"]["tmp_name"], $slika);

            $upit = "insert into korisnik values ('default','$tip','$korime','$lozinka','$ime','$prezime','$email','$slika')";
            $veza = spojiSeNaBazu();
            $izvrsi = izvrsiUpit($veza, $upit);


            echo "KORISNIK UNE�EN";
        } else
            $greska = "Korisnićko ime zauzeto!";
    }
}
?>



<!DOCTYPE html>
<html>

    <head>
        <meta charset="UTF-8" />
        <title>Registracija</title>
        <link href="stil_nav.css"  rel="stylesheet" type="text/css" />
	<link href="stil_inputa.css"  rel="stylesheet" type="text/css" />
        <style>

            form
            {
                position:absolute;
                top:40%;
                left:45%;
                width:18%;
            }
            h1 
            {
                position:absolute;
                top:25%;
                left:42%;
                font-family:arial;
                font-weight:normal;
            }
            input[type=text]
            {
                padding:5px; 
                border:2px solid #ccc; 
                border-radius: 5px;
            }
            input[type=password]
            {
                padding:5px; 
                border:2px solid #ccc; 
                border-radius: 5px;
            }
            input[type=password]:focus
            {
                border:3px solid #fbfb4a;
                border-radius: 5px;
            }

            input[type=text]:focus 
            {
                border:3px solid #fbfb4a;
                border-radius: 5px;
            }

            input[type=submit] 
            {
                float:right;
                padding:5px 15px; 
                background:#ccc; 
                border:0 none;
                cursor:pointer;
                border-radius: 5px; 
                color:white;
                font-weight: bold;
                font-size:17px;

            }
            #submit:hover{background:#fbfb4a}
            input[type=file] 
            {
                float:right;
                cursor:pointer;
                background:#ccc; 
                border:0 none;
                border-radius: 5px; 
                color:white;
                font-weight: bold;
                float:right;
            }
            #uploadslike{
                opacity:0;
                padding-bottom:20px;
                padding-right:-5px;
                background:#68FD7C;
                margin-bottom: 10%;
            }
            #slikalabel
            {
                background:#ccc;
                color:white;
                border-radius: 5px; 
                border-right:10px solid;
                border-left:10px solid;
                border-color:#ccc;
                width:90%;
                text-align:center;
                line-height: 180%;
                font-weight:bold;
                font-size:17px;
                font-family:arial;
                z-index: -1;
                margin-top: -5%;
            }

            label
            {
                font-size:20px;
            }
            body
            {

                color:chocolate;
                background:#fbfbf0;

            }
            div{
                color:red;
                font-size:19px;
            }

        </style>
    </head>

    <body>
        <header class="header">
            <nav>
                <ul>

                    <li>
                        <a href="o_autoru.html">O autoru</a>
                    </li>

                    <li>
                        <a href="index.php ">Index</a>
                    </li>
                    <?php echo $moderator; ?>

                    <?php echo $kor_nav; ?>

                    <?php echo $admin; ?>


                </ul>
            </nav>
        </header>
        <h1>UNESITE KORISNIKA</h1>
        <form action="<?php echo $_SERVER["PHP_SELF"] ?>" name="registracija" id="registracija" method="POST" enctype="multipart/form-data">

            <label for ="tip">Odaberite tip korisnika</label><br>
            <select name="tip">
                <?php
                $upit_tip = "select * from tip_korisnika";
                $tipovi_objekt = izvrsiUpit($veza, $upit_tip);
                $tip = "";
                while ($red = mysqli_fetch_array($tipovi_objekt)) {
                    $tip = $tip . "<option value = " . $red["tip_korisnika_id"] . ">" . $red['naziv'] . "</option>";
                }
                echo $tip;
                ?>
            </select><br>
            <label for="korime">Korisnićko ime</label>
            <br>
            <input required name="korime" type="text" />
            <br>
            <label for="lozinka">Lozinka</label>
            <br>
            <input required name="lozinka" type="password" />
            <br>
            <label for="potvrdaloz">Potvrda lozinke</label>
            <br>
            <input required name="potvrdaloz" type="password" />
            <br>
            <label for="ime">Ime</label>
            <br>
            <input required name="ime" type="text" />
            <br>
            <label for="prezime">Prezime</label>
            <br>
            <input required name="prezime" type="text" />
            <br>
            <label for="email">E-mail</label>
            <br>
            <input required name="email" type="text" />
            <br>
            <label for="slika" id="slikalabel" style="position:absolute;height:30px; left:0%;top:83%;">Unesi sliku</label>
            <input name="slika" type="file" id="uploadslike" style="float:right;"   />

            <br>
            <input name="submit" id="submit" type="submit" value="Unesi" />
            <br>
            <br>
            <div><?php
                if (isset($greska)) {
                    echo $greska;
                }
                ?></div>
        </form>


    </body>

</html>