<?php

if (empty($_COOKIE))
	header ("Location: index.php");
if ($_COOKIE["tip"] != 1 )
	header ("Location: prijava.php");

include "nav.php";
include "baza.php";
$veza = SpojiSeNaBazu();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
    <title>Moderator</title>
	<link href="stil_nav.css"  rel="stylesheet" type="text/css" />
	<link href="stil_inputa.css"  rel="stylesheet" type="text/css" />
	<style>
	div
	{
		height:400px;
		width:65%;
		overflow:scroll;
		margin-top:3%;
		margin-bottom:3%;
		margin-left:auto;
		margin-right:auto;
	}
	form{
		float:left;
		width:15%;
		margin-left:5%;
		margin-right:0%;
		margin-top:3%;
		text-align:left;
	}
	#submit{margin-right:10%;}
	</style>
</head>
<body>
<header>
        <nav>
            <ul>

                <li>
                    <a href="o_autoru.html">O autoru</a>
                </li>
             
                <li>
                    <a href="korisnik_r.php">Korisnik</a>
                </li>
				<li>
                    <a href="index.php">Index</a>
                </li>
				
                    <?php echo $moderator;?>
                
				
				
					<?php echo $admin;?>
				

            </ul>
        </nav>
<form action="<?php echo $_SERVER["PHP_SELF"]?>" name="filter_izbor" method="POST">
<h2>Filtriraj po:</h2>
<br>
<label for="mjesto">Upišite izborno mjesto</label>
<br>
<input type="text" name="mjesto">
<br>
<label for="naziv">Upišite naziv izbora</label>
<br>
<input type="text" name="naziv">
<br>
<h2>Sortiraj po:</h2>
<br>
<input type="radio" name="sort" value="izborno_mjesto.naziv">Izborno mjesto
<br>
<input type="radio" name="sort" value="izbor.naziv">Naziv izbora
<br>
<input type="submit" id="submit" name="submit" value="Unesi">
<br>
</form>

<?php


$sort="";
$e="";

if (isset($_POST['submit']))
{
	$upit1="";
	
	$mjesto=strtoupper($_POST['mjesto']);
	$naziv=$_POST['naziv'];
	
	if (empty($_POST['mjesto']) && empty($_POST['naziv']) )
	{
		
		if (empty($_POST['sort']))
		{
			$upit="select * from izbor join izborno_mjesto on izbor.izborno_mjesto_id=izborno_mjesto.izborno_mjesto_id";
		}
		else
		{
		$sort=$_POST['sort'];
		$upit="select * from izbor join izborno_mjesto on izbor.izborno_mjesto_id=izborno_mjesto.izborno_mjesto_id ORDER BY $sort ASC";
		}
		
	}
	else
	{
	if (empty($_POST['sort']))
	{
	
            if(empty($_POST['mjesto']) && !empty($_POST['naziv'])){
                
                $upit= "select * from izbor join izborno_mjesto on izbor.izborno_mjesto_id=izborno_mjesto.izborno_mjesto_id WHERE izbor.naziv LIKE '%$naziv%'";
            }
            
            if (!empty($_POST['mjesto']) && empty($_POST['naziv'])){
                
                $upit= "select * from izbor join izborno_mjesto on izbor.izborno_mjesto_id=izborno_mjesto.izborno_mjesto_id WHERE izborno_mjesto.naziv LIKE '%$mjesto%'";
            }
            
            if (!empty($_POST['mjesto']) && !empty($_POST['naziv'])){
            
            $upit= "select * from izbor join izborno_mjesto on izbor.izborno_mjesto_id=izborno_mjesto.izborno_mjesto_id WHERE izborno_mjesto.naziv LIKE '%$mjesto%' OR izbor.naziv LIKE'%$naziv%'";
            
            }
        }
	else
	{
	$sort=$_POST['sort'];
        
         if(empty($_POST['mjesto']) && !empty($_POST['naziv'])){
                
                $upit= "select * from izbor join izborno_mjesto on izbor.izborno_mjesto_id=izborno_mjesto.izborno_mjesto_id WHERE izbor.naziv LIKE '%$naziv%' ORDER BY $sort asc ";
            }
            
            if (!empty($_POST['mjesto']) && empty($_POST['naziv'])){
                
                $upit= "select * from izbor join izborno_mjesto on izbor.izborno_mjesto_id=izborno_mjesto.izborno_mjesto_id WHERE izborno_mjesto.naziv LIKE '%$mjesto%' ORDER BY $sort asc ";
            }
            
            if (!empty($_POST['mjesto']) && !empty($_POST['naziv'])){
            
            $upit= "select * from izbor join izborno_mjesto on izbor.izborno_mjesto_id=izborno_mjesto.izborno_mjesto_id WHERE izborno_mjesto.naziv LIKE '%$mjesto%' OR izbor.naziv LIKE'%$naziv%' ORDER BY $sort asc ";
            
            }
	}
	}

	$rezultat=izvrsiUpit($veza,$upit);
}









else
{
	$upit="select * from izbor join izborno_mjesto on izbor.izborno_mjesto_id=izborno_mjesto.izborno_mjesto_id";
	$rezultat=izvrsiUpit($veza,$upit);
}
?>
<div>
<table align="center" id="azur_kor" border="1px" >
	<tr>
		<th colspan ="3"> <h2>Popis izbora</h2></th>
	</tr>
	<tr>
		<th>Izborno mjesto</th>
		<th>Naziv izbora</th>
		<th>Opis</th>
	</tr>
		<?php 
		while ($red=mysqli_fetch_array($rezultat)){
	?>
	
	<tr>
		<td><?php echo $red['naziv'];?></td>
		<td><?php echo $red['2'];?></td>
		<td><?php echo $red['5'];?></td>
	</tr>
	
	
	
	<?php
		}
	?>

</table>
</div>

</body>