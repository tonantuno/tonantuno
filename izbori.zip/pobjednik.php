<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
    <title>Moderator</title>
	<link href="stil_nav.css"  rel="stylesheet" type="text/css" />
	<link href="stil_inputa.css"  rel="stylesheet" type="text/css" />
<style>
	
	div
	{
            font-size:20px;
            color:red;
		width:100%;
		margin-left:auto;
                margin-right:auto;
                margin-top:4%;
                text-align:center;
	}
	h1
	{
	width:100%;
	font-size:30px;
	text-decoration: underline;
	text-align:center;
	}
	p
	{
		margin-left:42%;
	}
	#pobjednik
	{
		font-size:25px;
		font-weight:bold;
		color:#e21616;
		margin-left:auto;
                margin-right:auto;
                text-align:center;
                
	}
	#proglasi:hover{background:#fbfb4a;}
	form
	{
		margin-left:auto;
		margin-right:auto;
		width:50%;
		text-align:right;
	}
	input[type=submit]
	{
		margin-bottom: 2%;
		margin-left: 42%;
		float: left;
	}
</style>
</head>
<body>
<div></div>
<h1>Statistika izbora:</h1>
<?php 

include "nav.php";
include "baza.php";
if ($tip==4)
	header ("Location: prijava.php");
if (empty($_COOKIE))
	header ("Location: index.php");
if ($_COOKIE["tip"] == 3 )
	header ("Location: prijava.php");
$veza = SpojiSeNaBazu();
$moderator_id=$_COOKIE["id_korisnika"];
$id_izbora= $_GET['izbor_id'];



$upit_sveukupni_broj="SELECT COUNT(*) FROM `korisnik` JOIN kandidat ON kandidat.korisnik_id=korisnik.korisnik_id JOIN glas ON glas.kandidat_id=kandidat.kandidat_id 	WHERE izbor_id= '$id_izbora'";
$sveukupni_glasovi=izvrsiUpit($veza,$upit_sveukupni_broj);
$sveukupni_glasovi=mysqli_fetch_array($sveukupni_glasovi);
$sveuk=$sveukupni_glasovi['COUNT(*)'];


$pola= $sveuk / 2;


$upit= "select * from korisnik join kandidat on kandidat.korisnik_id = korisnik.korisnik_id where izbor_id = '$id_izbora'";
$rez=izvrsiUpit($veza,$upit);
$brojglasovapobjednika=0;
$id_pobjednika=0;
while ($red=mysqli_fetch_array($rez)){
$kandidat = $red ['ime'] ." ". $red ['prezime']." ".$red ['email']. "<br>" ;
$id_kandidata = $red ['kandidat_id'];
$upit_glas = "select COUNT(*) from glas where kandidat_id = '$id_kandidata' ";
$broj_glas=izvrsiUpit($veza,$upit_glas);
$broj = mysqli_fetch_array ($broj_glas);

if($broj ['COUNT(*)']>$brojglasovapobjednika){
	$brojglasovapobjednika=$broj ['COUNT(*)'];
	$id_pobjednika = $red ['kandidat_id'];
}
	
}
$upit= "select * from korisnik join kandidat on kandidat.korisnik_id = korisnik.korisnik_id where izbor_id = '$id_izbora'";
$rez=izvrsiUpit($veza,$upit);
echo "<br><br><br>";
while ($red=mysqli_fetch_array($rez)){
$kandidat = $red ['ime'] ." ". $red ['prezime']." ".$red ['email']. "<br>" ;
$id_kandidata = $red ['kandidat_id'];
$upit_glas = "select COUNT(*) from glas where kandidat_id = '$id_kandidata' ";
$broj_glas=izvrsiUpit($veza,$upit_glas);
$broj = mysqli_fetch_array ($broj_glas);
echo "<p><strong>Kandidat: </strong>".$kandidat."</p>";
echo "<p><strong>Broj glasova: </strong>".$broj['COUNT(*)']."</p>";

$glas=$broj['COUNT(*)'];
$decimal = $glas / $sveuk;
$postotak = number_format( $decimal * 100, 1 ) . '%'."<br><br>";
echo "<p><strong>Postotak glasova:</strong> ".$postotak."</p>";
}
?>



</head>
<body>
 <header>
        <nav>
            <ul>

                <li>
                    <a href="o_autoru.html">O autoru</a>
                </li>
             
                <li>
                    <a href="korisnik_r.php">Korisnik</a>
                </li>
				<li>
                    <a href="index.php">Index</a>
                </li>
				
                    <?php echo $moderator;?>
                
				
				
					<?php echo $admin;?>
				

            </ul>
        </nav>
   </header>
<form action="pobjednik.php?izbor_id=<?php echo $id_izbora ?>" name="unos_pobjednika" method="POST">

<?php

//provjera ako postoji netko da je vec izabran za pobjednika izbora

$provjera_upit="select* from kandidat where izbor_id='$id_izbora' and status='P'";
$provjera_rez=izvrsiUpit($veza,$provjera_upit);
$provjera= mysqli_fetch_array($provjera_rez);
if (!empty($provjera)){
    $kor_id=$provjera['korisnik_id'];
    $provjera_upit1="select * from korisnik where korisnik_id='$kor_id'";
    $provjera_rez1=izvrsiUpit($veza,$provjera_upit1);
    $provjera1= mysqli_fetch_array($provjera_rez1);
    $ime=$provjera1['ime']." ".$provjera1['prezime'].", korisnicko ime:".$provjera1['korisnicko_ime'];
    echo "<div>Odabran je pobjednik za ovaj izbor, kandidat:$ime</div>";
}



?>
<input id="proglasi" name="proglasi" type="submit" value="Proglasi pobjednika">
</form>
<?php
if (isset($_POST['proglasi']))	
{
    if ($brojglasovapobjednika>$pola)
{
	$upit_k="select * from korisnik join kandidat on korisnik.korisnik_id = kandidat.korisnik_id where kandidat_id='$id_pobjednika' ";
	$rezultat_upita=izvrsiUpit($veza,$upit_k);
	$pobjednik=mysqli_fetch_array($rezultat_upita);
	echo "<div>Pobjednik: " .$pobjednik['ime']." ".$pobjednik['prezime']." ima ".$brojglasovapobjednika." glas/ova</div>";
	
	$upit_update="update kandidat set status='P' where kandidat_id='$id_pobjednika'";
	$update=izvrsiUpit($veza,$upit_update);	
}
else{
	echo "Izbori su nevažeći, za 5 sekunde biti će te preusmjereni na dodavanje izbora";
header("Refresh: 5; url=upravljanje_izborima.php");
}
}

?>

</body>
<html>